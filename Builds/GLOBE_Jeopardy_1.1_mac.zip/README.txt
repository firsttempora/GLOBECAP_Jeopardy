Build time:          
Mar   1   17:07:12   2015

# GLOBECAP_Jeopardy
A Jeopardy-style career game created for the GLOBECAP outreach program.

This game allows you to present up to 30 answers and questions in an interactive format ideal for high school classes.

INSTALLATION: 
Mac
  Mac users need only download the "_mac" zip, unzip it and place the app contained in the resulting folder in the desired destination folder (/Applications is the usual place). 
  
PC (Windows)
  Windows users should download the "_windows" zip.  Be sure to put both the .exe and the _Data folder in the same place.  I recommend you create a folder in Program Files to put both the .exe and _data folder in.
